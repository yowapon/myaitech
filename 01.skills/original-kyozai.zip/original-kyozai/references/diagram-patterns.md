# 図解パターン集（インラインSVG＋CSS）

図が果たすべき仕事は、**文章では順番に読まないと分からない関係を一目で見せること**。見せたい関係は次の5つに分類できるので、まずどれかを決めてからパターンを選ぶ。

| 見せたいもの | パターン |
|---|---|
| 構造（何が何を含むか） | 1. 階層スタック / 2. 分解ツリー / 8. マトリクス |
| 流れ（何が何になるか） | 3. プロセスフロー / 4. ループ図 |
| 対比（どう違うか） | 5. Before/After / 8. マトリクス |
| 量（どれくらいか） | 6. バーチャート / 9. 比率バー |
| 時間（いつ何が） | 7. タイムライン |

## 共通ルール

- 色は `var(--accent)` `var(--green)` などのCSS変数か `currentColor`。**16進数のハードコードはダークモードで破綻する**ので使わない
- 文字は `class="svg-title"` `class="svg-label"` `class="svg-label-sm"`、箱は `class="svg-box"` / `class="svg-box-accent"` を使う（テンプレートのCSSで定義済み）
- `viewBox` は幅720前後、高さは中身に合わせる。`width`/`height` 属性は書かない（CSSで100%になる）
- 矢印マーカー `<marker id="ar">` はファイル内で1回だけ定義すれば以降のSVGでも `url(#ar)` で使える
- テキストは必ず `text-anchor` を指定して座標と揃える。ここがずれると図が一気に素人臭くなる
- **1つの図に詰め込む要素は7つまで**。それ以上は図を分ける

---

## 1. 階層スタック（レイヤー構造）

```html
<svg viewBox="0 0 720 250" role="img" aria-label="4層構造">
  <rect x="160" y="10"  width="400" height="52" rx="6" class="svg-box-accent"/>
  <text x="360" y="42" text-anchor="middle" class="svg-title">アプリケーション層</text>
  <rect x="160" y="70"  width="400" height="52" rx="6" class="svg-box"/>
  <text x="360" y="102" text-anchor="middle" class="svg-title">ロジック層</text>
  <rect x="160" y="130" width="400" height="52" rx="6" class="svg-box"/>
  <text x="360" y="162" text-anchor="middle" class="svg-title">データ層</text>
  <rect x="160" y="190" width="400" height="52" rx="6" class="svg-box"/>
  <text x="360" y="222" text-anchor="middle" class="svg-title">インフラ層</text>
  <text x="150" y="42"  text-anchor="end" class="svg-label-sm">利用者に近い</text>
  <text x="150" y="222" text-anchor="end" class="svg-label-sm">物理に近い</text>
</svg>
```

## 2. 分解ツリー（1つが複数に分かれる）

```html
<svg viewBox="0 0 720 220" role="img" aria-label="3要素への分解">
  <rect x="270" y="10" width="180" height="54" rx="8" class="svg-box-accent"/>
  <text x="360" y="43" text-anchor="middle" class="svg-title">全体</text>
  <path d="M360 64 V 90 M120 90 H 600 M120 90 V 116 M360 90 V 116 M600 90 V 116"
        class="svg-arrow" fill="none"/>
  <g>
    <rect x="30" y="116" width="180" height="80" rx="8" class="svg-box"/>
    <text x="120" y="148" text-anchor="middle" class="svg-title">要素A</text>
    <text x="120" y="170" text-anchor="middle" class="svg-label-sm">補足</text>
  </g>
  <g>
    <rect x="270" y="116" width="180" height="80" rx="8" class="svg-box"/>
    <text x="360" y="148" text-anchor="middle" class="svg-title">要素B</text>
    <text x="360" y="170" text-anchor="middle" class="svg-label-sm">補足</text>
  </g>
  <g>
    <rect x="510" y="116" width="180" height="80" rx="8" class="svg-box"/>
    <text x="600" y="148" text-anchor="middle" class="svg-title">要素C</text>
    <text x="600" y="170" text-anchor="middle" class="svg-label-sm">補足</text>
  </g>
</svg>
```

## 3. プロセスフロー（横並びの手順）

```html
<svg viewBox="0 0 720 150" role="img" aria-label="4ステップの流れ">
  <defs>
    <marker id="ar" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <path d="M0 0 L10 5 L0 10 z" fill="var(--text-faint)"/>
    </marker>
  </defs>
  <!-- x = 10, 190, 370, 550 / 幅150 / 隙間の矢印は幅30 -->
  <g><rect x="10"  y="40" width="150" height="70" rx="8" class="svg-box-accent"/>
     <text x="85"  y="70" text-anchor="middle" class="svg-title">① 入力</text>
     <text x="85"  y="92" text-anchor="middle" class="svg-label-sm">補足</text></g>
  <path d="M165 75 H 185" class="svg-arrow" marker-end="url(#ar)"/>
  <g><rect x="190" y="40" width="150" height="70" rx="8" class="svg-box"/>
     <text x="265" y="70" text-anchor="middle" class="svg-title">② 処理</text>
     <text x="265" y="92" text-anchor="middle" class="svg-label-sm">補足</text></g>
  <path d="M345 75 H 365" class="svg-arrow" marker-end="url(#ar)"/>
  <g><rect x="370" y="40" width="150" height="70" rx="8" class="svg-box"/>
     <text x="445" y="70" text-anchor="middle" class="svg-title">③ 変換</text></g>
  <path d="M525 75 H 545" class="svg-arrow" marker-end="url(#ar)"/>
  <g><rect x="550" y="40" width="150" height="70" rx="8" class="svg-box"/>
     <text x="625" y="70" text-anchor="middle" class="svg-title">④ 出力</text></g>
</svg>
```

## 4. ループ図（循環する）

```html
<svg viewBox="0 0 720 300" role="img" aria-label="4段階のサイクル">
  <g><rect x="270" y="10"  width="180" height="60" rx="8" class="svg-box-accent"/>
     <text x="360" y="46" text-anchor="middle" class="svg-title">Plan</text></g>
  <g><rect x="510" y="120" width="180" height="60" rx="8" class="svg-box"/>
     <text x="600" y="156" text-anchor="middle" class="svg-title">Do</text></g>
  <g><rect x="270" y="230" width="180" height="60" rx="8" class="svg-box"/>
     <text x="360" y="266" text-anchor="middle" class="svg-title">Check</text></g>
  <g><rect x="30"  y="120" width="180" height="60" rx="8" class="svg-box"/>
     <text x="120" y="156" text-anchor="middle" class="svg-title">Act</text></g>
  <path d="M450 45  C 540 45, 600 70, 600 115"  class="svg-arrow" marker-end="url(#ar)"/>
  <path d="M600 185 C 600 230, 540 260, 455 260" class="svg-arrow" marker-end="url(#ar)"/>
  <path d="M270 260 C 180 260, 120 230, 120 185" class="svg-arrow" marker-end="url(#ar)"/>
  <path d="M120 115 C 120 70, 180 45, 265 45"    class="svg-arrow" marker-end="url(#ar)"/>
</svg>
```

## 5. Before / After（対比）

```html
<svg viewBox="0 0 720 200" role="img" aria-label="導入前と導入後の対比">
  <rect x="10" y="20" width="310" height="160" rx="8" fill="var(--bg)" stroke="var(--border-strong)" stroke-width="1.5"/>
  <text x="165" y="48" text-anchor="middle" class="svg-title" fill="var(--text-mute)">Before</text>
  <text x="165" y="82"  text-anchor="middle" class="svg-label">・課題1</text>
  <text x="165" y="108" text-anchor="middle" class="svg-label">・課題2</text>
  <text x="165" y="134" text-anchor="middle" class="svg-label">・課題3</text>

  <path d="M334 100 H 386" class="svg-arrow" stroke-width="2.5" marker-end="url(#ar)"/>

  <rect x="400" y="20" width="310" height="160" rx="8" fill="var(--accent-soft)" stroke="var(--accent)" stroke-width="1.5"/>
  <text x="555" y="48" text-anchor="middle" class="svg-title" fill="var(--accent)">After</text>
  <text x="555" y="82"  text-anchor="middle" class="svg-label">・改善1</text>
  <text x="555" y="108" text-anchor="middle" class="svg-label">・改善2</text>
  <text x="555" y="134" text-anchor="middle" class="svg-label">・改善3</text>
</svg>
```

## 6. バーチャート（量の比較 / 数値には必ず出典を）

```html
<svg viewBox="0 0 720 240" role="img" aria-label="項目別の値">
  <!-- 目盛り線 -->
  <line x1="140" y1="20" x2="140" y2="200" stroke="var(--border)"/>
  <line x1="140" y1="200" x2="700" y2="200" stroke="var(--border-strong)"/>
  <!-- バー: y=30,70,110,150 / 高さ28 / 値に比例した width -->
  <rect x="140" y="30"  width="480" height="28" rx="4" fill="var(--accent)"/>
  <text x="132" y="49"  text-anchor="end" class="svg-label">項目A</text>
  <text x="630" y="49"  class="svg-label-sm">48.0</text>
  <rect x="140" y="70"  width="320" height="28" rx="4" fill="var(--accent)" opacity=".72"/>
  <text x="132" y="89"  text-anchor="end" class="svg-label">項目B</text>
  <text x="470" y="89"  class="svg-label-sm">32.0</text>
  <rect x="140" y="110" width="180" height="28" rx="4" fill="var(--accent)" opacity=".52"/>
  <text x="132" y="129" text-anchor="end" class="svg-label">項目C</text>
  <text x="330" y="129" class="svg-label-sm">18.0</text>
  <rect x="140" y="150" width="90"  height="28" rx="4" fill="var(--accent)" opacity=".35"/>
  <text x="132" y="169" text-anchor="end" class="svg-label">項目D</text>
  <text x="240" y="169" class="svg-label-sm">9.0</text>
  <text x="140" y="225" class="svg-label-sm">単位: [[単位]] / 出典: [[出典名]]</text>
</svg>
```

## 7. タイムライン（時間の流れ）

```html
<svg viewBox="0 0 720 170" role="img" aria-label="年表">
  <line x1="40" y1="90" x2="690" y2="90" stroke="var(--border-strong)" stroke-width="2"/>
  <!-- x = 90, 250, 410, 570 -->
  <g><circle cx="90"  cy="90" r="8" fill="var(--accent)"/>
     <text x="90"  y="70"  text-anchor="middle" class="svg-title">1990s</text>
     <text x="90"  y="118" text-anchor="middle" class="svg-label-sm">出来事</text></g>
  <g><circle cx="250" cy="90" r="8" fill="var(--accent)" opacity=".8"/>
     <text x="250" y="70"  text-anchor="middle" class="svg-title">2010</text>
     <text x="250" y="118" text-anchor="middle" class="svg-label-sm">出来事</text></g>
  <g><circle cx="410" cy="90" r="8" fill="var(--accent)" opacity=".8"/>
     <text x="410" y="70"  text-anchor="middle" class="svg-title">2020</text>
     <text x="410" y="118" text-anchor="middle" class="svg-label-sm">出来事</text></g>
  <g><circle cx="570" cy="90" r="10" fill="var(--green)"/>
     <text x="570" y="68"  text-anchor="middle" class="svg-title">2026</text>
     <text x="570" y="118" text-anchor="middle" class="svg-label-sm">現在</text></g>
</svg>
```

## 8. 2×2マトリクス（軸で整理）

```html
<svg viewBox="0 0 720 340" role="img" aria-label="2軸のマトリクス">
  <rect x="120" y="20" width="500" height="260" fill="none" stroke="var(--border-strong)"/>
  <line x1="370" y1="20" x2="370" y2="280" stroke="var(--border)"/>
  <line x1="120" y1="150" x2="620" y2="150" stroke="var(--border)"/>
  <rect x="130" y="30" width="230" height="110" rx="6" fill="var(--accent-soft)" opacity=".6"/>
  <text x="245" y="80"  text-anchor="middle" class="svg-title">象限1</text>
  <text x="245" y="102" text-anchor="middle" class="svg-label-sm">説明</text>
  <text x="495" y="80"  text-anchor="middle" class="svg-title">象限2</text>
  <text x="245" y="210" text-anchor="middle" class="svg-title">象限3</text>
  <text x="495" y="210" text-anchor="middle" class="svg-title">象限4</text>
  <text x="370" y="308" text-anchor="middle" class="svg-label-sm">→ 横軸ラベル</text>
  <text x="105" y="150" text-anchor="end" class="svg-label-sm">↑ 縦軸ラベル</text>
</svg>
```

## 9. 比率バー（構成割合 / 合計100%）

```html
<svg viewBox="0 0 720 120" role="img" aria-label="構成比">
  <!-- 幅640を割合で分割。x累積に注意 -->
  <rect x="40" y="30" width="288" height="42" rx="4" fill="var(--accent)"/>
  <rect x="328" y="30" width="192" height="42" fill="var(--green)"/>
  <rect x="520" y="30" width="96"  height="42" fill="var(--amber)"/>
  <rect x="616" y="30" width="64"  height="42" rx="4" fill="var(--text-faint)"/>
  <text x="184" y="57" text-anchor="middle" class="svg-label" fill="#fff">A 45%</text>
  <text x="424" y="57" text-anchor="middle" class="svg-label" fill="#fff">B 30%</text>
  <text x="568" y="57" text-anchor="middle" class="svg-label" fill="#fff">C 15%</text>
  <text x="648" y="57" text-anchor="middle" class="svg-label-sm" fill="#fff">D 10%</text>
  <text x="40" y="98" class="svg-label-sm">出典: [[出典名]]</text>
</svg>
```

---

## よくある失敗

- **箇条書きを枠で囲んだだけ**：それは図ではない。要素どうしの関係（矢印・位置・大きさ）が無いなら、素直に本文か表にする
- **座標のズレ**：`<text>` の y は文字のベースライン。箱の中央に置くなら「箱のy + 高さ/2 + 5」くらいが目安
- **文字がはみ出す**：日本語は1文字 ≒ font-size と同じ幅。13pxで10文字なら約130px必要。箱幅が足りるか計算してから書く
- **色数の使いすぎ**：1つの図でアクセント色は1〜2色。強調したい要素だけ `svg-box-accent` にして、あとは `svg-box` に統一する
