#!/usr/bin/env python3
"""教材HTMLの自己点検。 使い方: python3 check_kyozai.py <教材.html>

毎回同じ検査を手書きすると時間もトークンも溶けるので、ここにまとめてある。
文字数・図の数・目次の整合・クイズの正解フラグ・色のハードコードを一度に見る。
"""
import re, sys

def main(path):
    h = open(path, encoding="utf-8").read()
    ng, ok = [], []

    # --- 本文の文字数（図の中の文字は除く。ここが一番の品質指標） ---
    m = re.search(r"<main.*?</main>", h, re.S)
    body = re.sub(r"<svg.*?</svg>", "", m.group(0) if m else h, flags=re.S)
    n = len(re.sub(r"\s+", "", re.sub(r"<[^>]+>", "", body)))
    (ok if 2200 <= n <= 4200 else ng).append(
        f"本文 {n}字（目標 2,500〜3,500字。多いと読まれない・少ないと薄い）")

    # --- 図の数 ---
    n_svg = len(re.findall(r"<svg", h))
    (ok if n_svg >= 8 else ng).append(f"インラインSVG {n_svg}点（8点以上）")

    # --- 目次とセクションidの対応 ---
    ids = set(re.findall(r'id="([^"]+)"', h))
    anchors = [a for a in re.findall(r'<a[^>]+href="#([^"]+)"', h) if a]
    miss = [a for a in anchors if a not in ids]
    (ok if anchors and not miss else ng).append(
        f"目次リンク {len(anchors)}件 / 対応しないid {miss}")

    # --- クイズ ---
    quizzes = re.findall(r'<div class="quiz".*?</div>\s*</div>', h, re.S)
    bad = []
    for i, q in enumerate(quizzes, 1):
        n_opt = len(re.findall(r'class="opt"', q))
        n_cor = len(re.findall(r"data-correct", q))
        if n_opt != 3 or n_cor != 1 or "explain" not in q:
            bad.append(f"Q{i}(選択肢{n_opt}/正解{n_cor})")
    (ok if len(quizzes) >= 3 and not bad else ng).append(
        f"クイズ {len(quizzes)}問（3問以上・全問3択・正解1つ・解説あり）不備:{bad}")

    # --- 図が本文より先か ---
    secs = [s for s in re.findall(r"<section[^>]*>(.*?)</section>", h, re.S) if "<svg" in s]
    good = sum(1 for s in secs
               if s.find("<figure") != -1 and (s.find("<p") == -1 or s.find("<figure") < s.find("<p")))
    (ok if secs and good == len(secs) else ng).append(f"図解→本文の順 {good}/{len(secs)}セクション")

    # --- 出典 ---
    urls = set(re.findall(r'href="(https?://[^"]+)"', h))
    (ok if len(urls) >= 5 else ng).append(f"出典URL {len(urls)}件（5件以上）")

    # --- 外部依存 ---
    cdn = re.findall(r'<(?:script|link)[^>]+(?:src|href)="https?://[^"]+', h)
    (ok if not cdn else ng).append(f"外部読み込み {len(cdn)}件（0であること）")

    # --- SVGの色ハードコード（ダークで図だけ浮く原因） ---
    hexes = []
    for s in re.findall(r"<svg.*?</svg>", h, re.S):
        hexes += [x for x in re.findall(r'(?:fill|stroke)="(#[0-9a-fA-F]{3,8})"', s)
                  if x.lower() not in ("#fff", "#ffffff", "#000", "#000000")]
    (ok if not hexes else ng).append(f"SVGの色ハードコード {sorted(set(hexes))[:6]}（var(--*)を使う）")

    for line in ok:
        print("  OK  " + line)
    for line in ng:
        print("  NG  " + line)
    print(f"\n{len(ok)}/{len(ok) + len(ng)} 合格")
    return 1 if ng else 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
