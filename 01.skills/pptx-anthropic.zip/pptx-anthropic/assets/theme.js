/**
 * pptx-anthropic — Anthropic ブランドカラーのスライドテーマ（pptxgenjs 用）
 *
 * 使い方:
 *   const pptxgen = require("pptxgenjs");
 *   const T = require("<この skill>/assets/theme.js").init(new pptxgen());
 *
 * init() は pres.layout を LAYOUT_WIDE（13.333 x 7.5 inch）に設定します。
 */

/* ---------------------------------------------------------------- palette */
const A = {
  // Ink（Anthropic black）— 見出し・締めのパネル・コードブロック
  ink: "141413",
  inkCard: "232220",
  inkLine: "38352F",
  inkBody: "B5B2A9",
  inkDim: "88857C",

  // Ivory — ベース背景
  cream: "F0EEE6", // Ivory Medium（ページ背景）
  creamLt: "FAFAF7", // Ivory Light（カード面）

  // 土系アクセント
  manilla: "EBDBBC", // ハイライト面
  kraft: "D4A27F", // サブアクセント／ダーク面の小さめ文字
  clay: "CC785C", // Book Cloth = 主アクセント
  clayDp: "A8553A", // 濃いめのクレイ
  clayTxt: "B04A2E", // アイボリー上の小さい文字用（コントラスト確保）

  // ニュートラル
  slate: "5E5D59", // 本文
  dim: "8A8880", // フッター等
  line: "E1DED2", // カードの罫

  // コードブロック
  codeBg: "1B1A18",
  codeTx: "E8E5DC",
  codeCm: "8C8A82",
};

const LIGHT = {
  kind: "light",
  bg: A.cream,
  cardFill: A.creamLt,
  cardLine: A.line,
  title: A.ink,
  body: A.slate,
  eyebrow: A.clayTxt,
  foot: A.dim,
  shadowOpacity: 0.09,
  onCircle: A.ink,
};

const DARK = {
  kind: "dark",
  bg: A.ink,
  cardFill: A.inkCard,
  cardLine: A.inkLine,
  title: A.cream,
  body: A.inkBody,
  eyebrow: A.kraft,
  foot: A.inkDim,
  shadowOpacity: 0.4,
  onCircle: A.ink,
};

/* ------------------------------------------------------------ typography */
const FH = "Yu Gothic UI"; // 見出し
const FB = "Meiryo"; // 本文
const FM = "Consolas"; // コード

/* --------------------------------------------------------------- metrics */
const W = 13.333;
const H = 7.5;
const M = 0.7; // 左右マージン
const CW = W - M * 2; // コンテンツ幅 = 11.933
const CONTENT_TOP = 2.28; // 見出し下のコンテンツ開始位置
const CONTENT_BOTTOM = 6.85; // フッターの上端

function init(pres) {
  pres.layout = "LAYOUT_WIDE";

  const themeOf = new WeakMap();

  // pptxgenjs はオプションオブジェクトを破壊的に変更するため、毎回新しく作る
  const shadow = (t) => ({
    type: "outer",
    angle: 90,
    blur: t.shadowOpacity > 0.2 ? 14 : 10,
    offset: 2,
    color: "141413",
    opacity: t.shadowOpacity,
  });

  /** 背景を塗った新規スライドを返す。kind は "light" | "dark" */
  function slide(kind = "light") {
    const t = kind === "dark" ? DARK : LIGHT;
    const s = pres.addSlide();
    s.background = { color: t.bg };
    themeOf.set(s, t);
    return s;
  }

  const T = (s) => themeOf.get(s) || LIGHT;

  /** 角丸カード。fill / lineColor を渡すと上書きできる */
  function card(s, x, y, w, h, fill, lineColor) {
    const t = T(s);
    s.addShape(pres.ShapeType.roundRect, {
      x,
      y,
      w,
      h,
      rectRadius: 0.1,
      fill: { color: fill || t.cardFill },
      line: { color: lineColor || t.cardLine, width: 0.75 },
      shadow: shadow(t),
    });
  }

  /** 塗りつぶし円 + 中央のラベル（番号・記号）。このデッキの視覚モチーフ */
  function numCircle(s, x, y, d, label, opts = {}) {
    const t = T(s);
    s.addShape(pres.ShapeType.ellipse, {
      x,
      y,
      w: d,
      h: d,
      fill: { color: opts.fill || A.clay },
      line: { type: "none" }, // width:0 では枠線が消えない
    });
    s.addText(label, {
      x,
      y,
      w: d,
      h: d,
      align: "center",
      valign: "middle",
      margin: 0,
      fontFace: FH,
      fontSize: opts.size || 13,
      bold: true,
      color: opts.color || t.onCircle,
    });
  }

  /** ページ見出し（eyebrow / title / lead）。lead は省略可 */
  function head(s, eyebrow, title, lead) {
    const t = T(s);
    s.addText(eyebrow, {
      x: M,
      y: 0.46,
      w: 9,
      h: 0.28,
      margin: 0,
      fontFace: FH,
      fontSize: 11,
      bold: true,
      charSpacing: 3,
      color: t.eyebrow,
    });
    s.addText(title, {
      x: M,
      y: 0.76,
      w: CW,
      h: 0.66,
      margin: 0,
      fontFace: FH,
      fontSize: 31,
      bold: true,
      color: t.title,
    });
    if (lead) {
      s.addText(lead, {
        x: M,
        y: 1.5,
        w: CW - 0.5,
        h: 0.42,
        margin: 0,
        fontFace: FB,
        fontSize: 13.5,
        color: t.body,
        lineSpacingMultiple: 1.25,
      });
    }
  }

  /** フッター（左ラベル / 右ページ番号） */
  function foot(s, n, label) {
    const t = T(s);
    s.addText(label || "", {
      x: M,
      y: 6.98,
      w: 7,
      h: 0.3,
      margin: 0,
      fontFace: FB,
      fontSize: 9.5,
      color: t.foot,
    });
    s.addText(String(n).padStart(2, "0"), {
      x: W - M - 1,
      y: 6.98,
      w: 1,
      h: 0.3,
      margin: 0,
      align: "right",
      fontFace: FH,
      fontSize: 10,
      bold: true,
      color: t.foot,
    });
  }

  /**
   * ターミナル風のコードカード。
   * lines: [{ t: "行", c: 色(省略可), b: 太字(省略可) }, ...]
   * 空行は { t: "" } を入れる
   */
  function codeCard(s, x, y, w, h, lines) {
    const t = T(s);
    s.addShape(pres.ShapeType.roundRect, {
      x,
      y,
      w,
      h,
      rectRadius: 0.08,
      fill: { color: A.codeBg },
      line: { type: "none" },
      shadow: shadow(t),
    });
    const rich = lines.map((l, i) => ({
      text: l.t,
      options: {
        breakLine: i !== lines.length - 1,
        color: l.c || A.codeCm,
        bold: !!l.b,
      },
    }));
    s.addText(rich, {
      x: x + 0.28,
      y: y + 0.24,
      w: w - 0.56,
      h: h - 0.48,
      margin: 0,
      valign: "top",
      fontFace: FM,
      fontSize: 10.5,
      lineSpacingMultiple: 1.32,
    });
  }

  /** 枠線なしの塗りつぶし図形（装飾の円など） */
  function blob(s, shapeType, x, y, w, h, color) {
    s.addShape(shapeType, {
      x,
      y,
      w,
      h,
      fill: { color },
      line: { type: "none" },
    });
  }

  /** n 等分カラムの座標計算。cols(4).x(2) で3列目の x が取れる */
  function cols(n, gap = 0.32) {
    const w = (CW - gap * (n - 1)) / n;
    return { w, gap, x: (i) => M + (w + gap) * i };
  }

  return {
    pres,
    A,
    LIGHT,
    DARK,
    FH,
    FB,
    FM,
    W,
    H,
    M,
    CW,
    CONTENT_TOP,
    CONTENT_BOTTOM,
    slide,
    card,
    numCircle,
    head,
    foot,
    codeCard,
    blob,
    cols,
  };
}

module.exports = {
  init,
  A,
  LIGHT,
  DARK,
  FH,
  FB,
  FM,
  W,
  H,
  M,
  CW,
  CONTENT_TOP,
  CONTENT_BOTTOM,
};
