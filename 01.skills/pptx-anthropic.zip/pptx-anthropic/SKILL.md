---
name: pptx-anthropic
description: "Anthropic ブランドカラー（Ivory / Book Cloth / Kraft / Ink）で日本語のプレゼン資料を作るときに使う。スライド、デッキ、プレゼン、提案資料、勉強会資料、社内説明資料、pptx、パワーポイント、presentation、deck の作成・デザイン依頼で発動する。配色・書体・レイアウト規約と、再利用できる pptxgenjs のテーマモジュールを提供する。Windows + PowerPoint 環境での検証手順も含む。"
---

# Anthropic カラーのスライドデザイン

Anthropic のブランドパレットで、日本語のプレゼン資料を作るためのデザイン規約とテーマモジュール。

**このスキルは `pptx` スキルと併用する。** 役割分担は次のとおり。

| | 担当 |
|---|---|
| `pptx` スキル | pptxgenjs の作法、ファイル検証、QA 手順 |
| **このスキル** | 配色・書体・レイアウト規約、再利用パーツ、環境固有の注意点 |

まず `pptx` スキルの手順に従い、配色とレイアウトは以下の規約を使う。

---

## パレット

`assets/theme.js` の `A` に定義済み。ハードコードせず参照すること。

| 役割 | 色 | 名称 |
|---|---|---|
| ページ背景（本文） | `F0EEE6` | Ivory Medium |
| カード面 | `FAFAF7` | Ivory Light |
| 見出し・本文の黒 | `141413` | Ink |
| **主アクセント** | `CC785C` | **Book Cloth** |
| 濃いクレイ | `A8553A` | Clay |
| サブアクセント | `D4A27F` | Kraft |
| ハイライト面 | `EBDBBC` | Manilla |
| 本文グレー | `5E5D59` | Slate |
| カード罫 | `E1DED2` | — |

### コントラストの決まりごと

アイボリー地に `CC785C` を**小さい文字**で置くとコントラスト比 2.8 で読めない。文字色には `B04A2E`（`A.clayTxt`）を使う。`CC785C` は円・パネル・大きい見出しなど**面と大きな要素**に限る。

| 組み合わせ | 比 | 用途 |
|---|---|---|
| Ink on Ivory | 15.9 | 見出し・本文 |
| Slate on Ivory | 5.6 | 本文 |
| `B04A2E` on Ivory | 4.7 | 小さいアクセント文字 |
| Ink on Book Cloth | 5.6 | 円の中の番号、クレイ面の文字 |
| Kraft on Ink | 8.2 | ダーク面の小さい文字 |

---

## 構成のルール

### サンドイッチではなく「アイボリー基調 + Ink のアクセント」

全ページをアイボリーで統一し、**ダークは意味のある場所だけ**に使う。

- コードブロック → Ink 面（ターミナルの見立て）
- 最終ページの締めのパネル → Ink 面（終止符として効かせる）
- それ以外の面はアイボリー

表紙もアイボリー。ダークな表紙にしたい場合は `slide("dark")` が使えるが、既定はライト。

### 表紙

右側に **Manilla と Book Cloth のフラットな円を画面外へブリード**させる。Anthropic のキービジュアルでよく使われる「大きな面で色を置く」表現。テキストは左に寄せ、円と重ならないよう幅を 8.0 inch 程度に抑える。

### 視覚モチーフ

**塗りつぶし円の中に番号・記号**（`numCircle`）を全ページで繰り返す。これが唯一のモチーフ。

### やらないこと

- タイトル下のアクセント線 — AI 生成スライドの典型
- カラーバー、サイドストライプ、カード片側だけの罫
- 全ページ同じレイアウト（カード列 / 2カラム / コード+説明 / グリッドを使い分ける）
- 本文の中央揃え（中央揃えはタイトルのみ）

---

## 書体

| 用途 | フォント | サイズ |
|---|---|---|
| 見出し | Yu Gothic UI Bold | 31pt（ページ見出し）/ 52pt（表紙） |
| 本文 | Meiryo | 11.5〜13.5pt |
| コード・コマンド | Consolas | 10.5〜11.5pt |

いずれも Windows 標準搭載。日本語は行間を広めに取る（`lineSpacingMultiple: 1.2〜1.4`）。

---

## テーマモジュールの使い方

`assets/theme.js` に配色とレイアウトのヘルパーがある。作業ディレクトリにコピーするか、絶対パスで require する。

```js
const pptxgen = require("pptxgenjs");
const T = require("./theme.js").init(new pptxgen());
const { A, M, CW } = T;

// --- 表紙 ---
const E = T.pres.ShapeType.ellipse;
const cover = T.slide("light");
T.blob(cover, E, 8.6, -1.2, 6.4, 6.4, A.manilla); // 奥
T.blob(cover, E, 10.6, 3.2, 5.0, 5.0, A.clay); // 手前
cover.addText("タイトル", {
  x: M, y: 2.3, w: 8.0, h: 2.2, margin: 0,
  fontFace: T.FH, fontSize: 52, bold: true, color: A.ink,
  lineSpacingMultiple: 1.12,
});

// --- 本文ページ ---
const s = T.slide("light");
T.head(s, "OVERVIEW", "ページ見出し", "リード文をここに置く。");

const c = T.cols(3);              // 3カラムの座標計算
[0, 1, 2].forEach((i) => {
  T.card(s, c.x(i), 2.4, c.w, 3.2);
  T.numCircle(s, c.x(i) + 0.3, 2.7, 0.58, `0${i + 1}`, { size: 14 });
  s.addText("見出し", {
    x: c.x(i) + 0.3, y: 3.5, w: c.w - 0.6, h: 0.4, margin: 0,
    fontFace: T.FH, fontSize: 17, bold: true, color: A.ink,
  });
});
T.foot(s, 2, "セクション名");

T.pres.writeFile({ fileName: "deck.pptx" });
```

### ヘルパー一覧

| 関数 | 用途 |
|---|---|
| `slide("light"\|"dark")` | 背景を塗った新規スライド |
| `head(s, eyebrow, title, lead)` | ページ見出し3点セット |
| `foot(s, n, label)` | フッター（左ラベル / 右ページ番号） |
| `card(s, x, y, w, h, fill?, line?)` | 角丸カード（影付き） |
| `numCircle(s, x, y, d, label, opts?)` | 番号入りの塗りつぶし円 |
| `codeCard(s, x, y, w, h, lines)` | ターミナル風コードカード |
| `blob(s, type, x, y, w, h, color)` | 枠線なしの装飾図形 |
| `cols(n, gap?)` | n 等分カラムの `w` と `x(i)` |

### レイアウトの基準値

- 左右マージン `M = 0.7`、コンテンツ幅 `CW = 11.933`
- コンテンツ領域は y `2.28` 〜 `6.85`、フッターは y `6.98`
- カード間の間隔は `0.32` か `0.42` に統一する
- カード内の下余白は 0.3〜0.5 inch。**1 inch 以上空いたらカードが高すぎる**ので縮める

### コードカードの高さ計算

`codeCard` は 10.5pt / 行間 1.32 で、**1行あたり約 0.233 inch**。上下パディングが 0.48 inch あるので:

```
必要な高さ = 行数 × 0.233 + 0.48
```

12行なら 3.28、15行なら 3.98 inch。目分量で置くと必ず下が切れるので、行数から逆算すること。入らない場合はカードを伸ばすのではなく、**コードの行数を削る**（空行を詰める、変数をまとめる）。

---

## この環境（Windows）での注意点

### 1. 図形の枠線は `width: 0` では消えない

```js
line: { width: 0 }      // ✕ 細い枠線が残る
line: { type: "none" }  // ○
```

装飾の円やチップに意図しない輪郭が出る原因。`theme.js` のヘルパーは対応済みだが、自前で `addShape` を書くときは注意。

### 2. 幅または高さ 0 の図形はファイルを壊す

`addShape` に `w: 0` や `h: 0` を渡すと、**`validate.py` は通るのに PowerPoint が「ファイルを開けません」で拒否する**。python-pptx でも開けてしまうため、PNG 書き出しに失敗して初めて気づく。

書きかけの行やデバッグ用の呼び出しを消し忘れたときに起きやすい。PowerPoint が開けないときは、まず `0` を渡している `addShape` / `card` を探すこと。

### 3. validate.py は日本語で落ちる

Python の既定エンコーディングが cp932 のため、日本語を含む XML の読み取りに失敗する。UTF-8 モードを付ける。

```bash
PYTHONUTF8=1 python <pptx skill>/scripts/office/validate.py deck.pptx
```

エラーが `'cp932' codec can't decode byte` なら、デッキの不備ではなく検証スクリプト側の問題。

### 4. LibreOffice が無いので目視確認は PowerPoint COM で行う

`soffice` / `pdftoppm` は未インストール。PowerPoint 本体を COM 経由で使って PNG に書き出す。**実際のレンダラで確認できるのでフォント置換の心配がない**という利点がある。

```powershell
$dir = "<作業ディレクトリ>"
$out = Join-Path $dir "png"
if (Test-Path $out) { Remove-Item $out -Recurse -Force }
$app = New-Object -ComObject PowerPoint.Application
$pres = $app.Presentations.Open((Join-Path $dir "deck.pptx"), $true, $false, $false)
$pres.Export($out, "PNG", 1600, 900)
$pres.Close()
$app.Quit()
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($app) | Out-Null
```

出力は `スライド1.PNG`〜（日本語ファイル名）。生成後は必ず全ページを目視して、はみ出し・重なり・余白の偏りを確認する。

### 5. pptxgenjs と Python 依存は都度インストール

作業ディレクトリで `npm install pptxgenjs`、検証用に `pip install python-pptx Pillow lxml defusedxml`。`markitdown` は未導入なので、本文の抽出は `python-pptx` で行う。

---

## 進め方

1. 構成（ページ数と各ページの役割）を決める
2. `theme.js` を作業ディレクトリにコピーし、生成スクリプトを書く
3. 生成 → `PYTHONUTF8=1` 付きで `validate.py`
4. PowerPoint COM で PNG 書き出し → **全ページ目視**
5. 余白・はみ出しを直して再生成（4 を再実行）
